/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.14432989690722, "KoPercent": 1.8556701030927836};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.01752577319587629, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.020491803278688523, 500, 1500, "Post /index.php(click on add to cart)"], "isController": false}, {"data": [0.0, 500, 1500, "GET index.php?controller=order(click on proceed to checkout)"], "isController": false}, {"data": [0.0, 500, 1500, "GET /"], "isController": false}, {"data": [0.0625, 500, 1500, "GET /index.php?controller=order&step=1(click on proceed to checkout again)-0"], "isController": false}, {"data": [0.0, 500, 1500, "POST /index.php(choose address and proceed to checkout)"], "isController": false}, {"data": [0.0, 500, 1500, "POST /index.php(click on I confirm my order)-0"], "isController": false}, {"data": [0.0, 500, 1500, "GET /-1"], "isController": false}, {"data": [0.0, 500, 1500, "POST /index.php(click on I confirm my order)-1"], "isController": false}, {"data": [0.07407407407407407, 500, 1500, "GET /-0"], "isController": false}, {"data": [0.0, 500, 1500, "GET /index.php?controller=order&step=1(click on proceed to checkout again)-1"], "isController": false}, {"data": [0.0, 500, 1500, "POST /index.php(enter user details and click on register)"], "isController": false}, {"data": [0.0, 500, 1500, "POST /index.php(click on I confirm my order)"], "isController": false}, {"data": [0.045454545454545456, 500, 1500, "POST /index.php(enter email id and click on create and account)"], "isController": false}, {"data": [0.0, 500, 1500, "POST /index.php(enter user details and click on register)-1"], "isController": false}, {"data": [0.0, 500, 1500, "GET /index.php(choose payment method)"], "isController": false}, {"data": [0.0, 500, 1500, "POST /index.php(choose shipping option and proceed to checkout)-1"], "isController": false}, {"data": [0.0625, 500, 1500, "POST /index.php(enter user details and click on register)-0"], "isController": false}, {"data": [0.0, 500, 1500, "GET /index.php?controller=order&step=1(click on proceed to checkout again)"], "isController": false}, {"data": [0.0, 500, 1500, "POST /index.php(choose shipping option and proceed to checkout)"], "isController": false}, {"data": [0.03125, 500, 1500, "POST /index.php(choose shipping option and proceed to checkout)-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 485, 9, 1.8556701030927836, 4998.812371134021, 1, 16667, 4454.0, 9330.6, 10590.699999999999, 13686.339999999993, 1.5405188213284038, 39.91761450263476, 1.4065950533861238], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Post /index.php(click on add to cart)", 122, 0, 0.0, 3662.2213114754104, 1142, 6898, 3379.5, 5692.3, 6066.75, 6800.479999999999, 0.41282463412570847, 0.8523265005075713, 0.31338560612469335], "isController": false}, {"data": ["GET index.php?controller=order(click on proceed to checkout)", 24, 0, 0.0, 5569.958333333332, 2549, 8594, 4935.0, 7845.0, 8425.75, 8594.0, 0.09527401202834401, 4.878606270220916, 0.0618102558504198], "isController": false}, {"data": ["GET /", 27, 0, 0.0, 7157.7037037037035, 4055, 9723, 6837.0, 9634.8, 9690.6, 9723.0, 0.08662453078379158, 6.9871983180403605, 0.06420704967275177], "isController": false}, {"data": ["GET /index.php?controller=order&step=1(click on proceed to checkout again)-0", 24, 0, 0.0, 3464.166666666668, 988, 5894, 3243.0, 5468.0, 5846.5, 5894.0, 0.09670478446921162, 0.049296774895437954, 0.06339955596386465], "isController": false}, {"data": ["POST /index.php(choose address and proceed to checkout)", 16, 0, 0.0, 6300.25, 2307, 9620, 6672.5, 9118.800000000001, 9620.0, 9620.0, 0.08645470853956383, 3.293130768150085, 0.08918807884129076], "isController": false}, {"data": ["POST /index.php(click on I confirm my order)-0", 12, 0, 0.0, 5239.666666666667, 2719, 6605, 5665.5, 6590.9, 6605.0, 6605.0, 0.06874308988731861, 0.027121297182106176, 0.06950391835612359], "isController": false}, {"data": ["GET /-1", 27, 0, 0.0, 4558.407407407407, 2485, 6519, 4599.0, 6395.0, 6506.2, 6519.0, 0.08727865164180841, 7.013878871373896, 0.03272949436567816], "isController": false}, {"data": ["POST /index.php(click on I confirm my order)-1", 12, 0, 0.0, 4091.583333333334, 1700, 6083, 4169.0, 5837.000000000001, 6083.0, 6083.0, 0.07028394714647175, 1.9448943196660342, 0.07264047271811452], "isController": false}, {"data": ["GET /-0", 27, 0, 0.0, 2598.925925925925, 1309, 3995, 2502.0, 3570.2, 3910.1999999999994, 3995.0, 0.0873823170554101, 0.02611229396382372, 0.03200036024978397], "isController": false}, {"data": ["GET /index.php?controller=order&step=1(click on proceed to checkout again)-1", 24, 0, 0.0, 4498.333333333334, 1736, 7536, 4330.5, 7412.5, 7522.5, 7536.0, 0.09766817238432426, 4.230455396929557, 0.07833801326659341], "isController": false}, {"data": ["POST /index.php(enter user details and click on register)", 16, 0, 0.0, 8956.5, 3449, 14733, 9248.5, 14320.0, 14733.0, 14733.0, 0.08725146964194179, 3.4321077058044045, 0.18966969865523675], "isController": false}, {"data": ["POST /index.php(click on I confirm my order)", 12, 0, 0.0, 9332.333333333334, 4421, 12122, 9769.0, 12011.0, 12122.0, 12122.0, 0.06807931239894478, 1.9107471793180724, 0.13919471392505603], "isController": false}, {"data": ["POST /index.php(enter email id and click on create and account)", 22, 5, 22.727272727272727, 2046.5909090909095, 1, 4035, 2231.5, 3803.5, 4004.0999999999995, 4035.0, 0.09202941594786115, 1.6595974066006007, 0.06144417814594192], "isController": false}, {"data": ["POST /index.php(enter user details and click on register)-1", 16, 0, 0.0, 5600.5, 1935, 9345, 5872.5, 9090.2, 9345.0, 9345.0, 0.08785223254485955, 3.375061427928225, 0.08479584994289605], "isController": false}, {"data": ["GET /index.php(choose payment method)", 16, 4, 25.0, 4195.750000000001, 1, 8179, 4693.5, 7854.200000000001, 8179.0, 8179.0, 0.08840316262314285, 2.4412308897225796, 0.061079333550657776], "isController": false}, {"data": ["POST /index.php(choose shipping option and proceed to checkout)-1", 16, 0, 0.0, 5813.375000000001, 3506, 9321, 5496.5, 8686.1, 9321.0, 9321.0, 0.08546506348451748, 3.243457582620679, 0.08108330974141476], "isController": false}, {"data": ["POST /index.php(enter user details and click on register)-0", 16, 0, 0.0, 3355.25, 925, 6393, 3330.5, 6162.0, 6393.0, 6393.0, 0.08942444193559204, 0.08212159139177966, 0.1080800048345089], "isController": false}, {"data": ["GET /index.php?controller=order&step=1(click on proceed to checkout again)", 24, 0, 0.0, 7962.875, 2857, 12401, 6796.0, 12328.0, 12390.25, 12401.0, 0.09597389510053266, 4.205992688738663, 0.1398994473503207], "isController": false}, {"data": ["POST /index.php(choose shipping option and proceed to checkout)", 16, 0, 0.0, 10991.5625, 4678, 16667, 10430.0, 15224.300000000001, 16667.0, 16667.0, 0.08355004125283287, 3.2552695272112038, 0.1665187406658938], "isController": false}, {"data": ["POST /index.php(choose shipping option and proceed to checkout)-0", 16, 0, 0.0, 5177.5, 1171, 8252, 5305.5, 7793.5, 8252.0, 8252.0, 0.08574444938665923, 0.08670739974598207, 0.08954391656529172], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: automationpractice.com:80 failed to respond", 9, 100.0, 1.8556701030927836], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 485, 9, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: automationpractice.com:80 failed to respond", 9, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["POST /index.php(enter email id and click on create and account)", 22, 5, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: automationpractice.com:80 failed to respond", 5, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET /index.php(choose payment method)", 16, 4, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: automationpractice.com:80 failed to respond", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
